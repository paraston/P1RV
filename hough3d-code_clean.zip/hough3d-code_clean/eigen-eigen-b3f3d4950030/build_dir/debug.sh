#!/bin/sh

cmake -DCMAKE_BUILD_TYPE=Debug .
