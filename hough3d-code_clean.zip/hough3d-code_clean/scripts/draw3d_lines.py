from math import sqrt

import mpl_toolkits
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

import numpy as np

open_file_path = "/home/eleve/Documents/P1RV/hough3d-code/output_test_raw.txt"
pointcloud_file_path_2 = "/home/eleve/Documents/P1RV/hough3d-code/testdata.dat"

# Open a file
open_file = open(open_file_path, "r")

# Make a 3d plotting environment
fig = plt.figure()
ax = fig.gca(projection='3d')
t_space = np.linspace(0, 1, 1000)

i = 0
for line in open_file:
    i = i+1 # vaut 1 a la ligne 1, etc...

    if( line[0] == '#'):
        continue

    if (i > 2):

        lineWords = line.split(' ')

        a = [ float( lineWords[6] ), float( lineWords[7] ), float( lineWords[8] ) ] # point de depart
        c = [ float( lineWords[9] ), float( lineWords[10] ), float( lineWords[11] ) ] # point d'arrivee
        minusa = [-a[0], -a[1], -a[2]]
        b = map(sum, zip(c,minusa)) # vecteur directeur non normalise

        segLength = sqrt( b[0]**2 + b[1]**2 + b[2]**2 )
        density = float( lineWords[12] ) / segLength
        print(density)

        if( density > 0.0 ): # a changer pour exclure les lignes de faible densite de l'affichage...

            ax.scatter3D( (a[0], c[0]), (a[1], c[1]), (a[2], c[2]), '+' ) # plot extremity points

            xline = [ a[0] + t * b[0] for t in t_space ]
            yline = [ a[1] + t * b[1] for t in t_space ]
            zline = [ a[2] + t * b[2] for t in t_space ]

            ax.plot3D(xline, yline, zline, 'gray') # plot the segment

open_file.close()

"""
# Open pointcloud file
open_file = open(pointcloud_file_path_2, "r")

i=0
for line in open_file:
    i = i+1 # vaut 1 a la ligne 1, etc...

    if( line[0] == '#'):
        continue

    if( i % 50 == 0 ): # affiche un point sur 50

        lineWords = line.split(',')
        point = [ float( lineWords[0] ), float( lineWords[1] ), float( lineWords[2] ) ]
        ax.scatter( point[0], point[1], point[2], c='r', marker=',' ) # plot pointcloud points
"""

plt.show()



