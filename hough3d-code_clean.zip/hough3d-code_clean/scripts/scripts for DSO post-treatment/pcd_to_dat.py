# Open a file
open_file = open("/home/eleve/dso_with_saving_pcl/build/pcl_data.pcd", "r")
result_file = open("/home/eleve/dso_with_saving_pcl/build/pcl_data_Box0_light.dat", "w")

i = 0
for line in open_file:
    i = i+1
    if (i > 10):
        lineWords = line.split( )
        j = 0
        for word in lineWords:
            j = j+1
            result_file.write( word )
            if( j < 3 ):
                 result_file.write( "," )
        result_file.write( "\n")

open_file.close()
result_file.close()
