# Script to rescale a pointcloud and/or cut out from its Center of masses

# Parameters

culling_dist = 150.0
rescale = True
scale = 200.0

# Open a file

open_file_path = "/home/eleve/dso_with_saving_pcl/build/pcl_data_Box0_light.dat"

open_file = open(open_file_path, "r")

if( rescale ):
    result_file = open("/home/eleve/dso_with_saving_pcl/build/pcl_data_Box0_light_CR.dat", "w")
else:
    result_file = open("/home/eleve/dso_with_saving_pcl/build/pcl_data_Box0_light_C.dat", "w")


from math import sqrt

def norme( (x, y, z), (b_x, b_y, b_z) ):
    return sqrt( ( x - b_x )**2 + ( y - b_y )**2 + ( z - b_z )**2 )

# calculer barycentre du nuage

i = 0
baryX = 0
baryY = 0
baryZ = 0

for line in open_file:

    i = i+1
    lineWords = line.split(',')

    if( len(lineWords) < 3 ):
        print(i)
        continue
    else:
        lineWords[2] = lineWords[2].replace('\n', '')

    print(lineWords)

    j = 0
    for word in lineWords:
        j = j+1
        float_coord = float(word)

        if( j == 1 ): # x coord
            baryX += float_coord

        if( j == 2 ): # y coord
            baryY += float_coord

        if( j == 3 ): # z coord
            baryZ += float_coord

baryX = baryX / float(i)
baryY = baryY / float(i)
baryZ = baryZ / float(i)

# eliminer les points trop lointains

open_file.close()
open_file = open(open_file_path, "r")

for line in open_file:

    lineWords = line.split(',')

    if( len(lineWords) < 3 ):
        print(i)
        continue
    else:
        lineWords[2] = lineWords[2].replace('\n', '')

    if( norme( (float(lineWords[0]), float(lineWords[1]), float(lineWords[2])), (baryX, baryY, baryZ) ) < culling_dist ):
        j = 0
        for word in lineWords:
            j = j+1
            if( rescale ):
                rescaled_word = scale * float(word)
                result_file.write( str(rescaled_word) )
            else:
                result_file.write( word )
            if( j < 3 ):
               result_file.write( "," )

        result_file.write( "\n")

open_file.close()
result_file.close()
