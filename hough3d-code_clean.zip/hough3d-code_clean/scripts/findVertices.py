from math import sqrt, pi

import mpl_toolkits
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

import numpy as np

open_file_path = "/home/eleve/Documents/P1RV/hough3d-code/output_test_raw_pyramide.txt"
save_file_path = "/home/eleve/Documents/P1RV/hough3d-code/triangles_test_raw_pyramide.txt"

# Open a file
open_file = open(open_file_path, "r")
"""
# Make a 3d plotting environment
fig = plt.figure()
ax = fig.gca(projection='3d')
t_space = np.linspace(0, 1, 1000)
"""

"----------------------------------------------------------------------------------------------------------------"

# Make a list of segments: list of doublets of 3d points (triplets)
listSegments = []

i = 0
for line in open_file:
    i = i+1 # vaut 1 a la ligne 1, etc...

    if( line[0] == '#'):
        continue

    if (i > 2):

        lineWords = line.split(' ')

        a = [ float( lineWords[6] ), float( lineWords[7] ), float( lineWords[8] ) ] # point de depart
        c = [ float( lineWords[9] ), float( lineWords[10] ), float( lineWords[11] ) ] # point d'arrivee
        minusa = [-a[0], -a[1], -a[2]]
        b = map(sum, zip(c,minusa)) # vecteur directeur non normalise

        segLength = sqrt( b[0]**2 + b[1]**2 + b[2]**2 )
        density = float( lineWords[12] ) / segLength

        if( density > 0.0 ): # a changer pour exclure les segments de faible densite de la liste...

            listSegments.append( [ a, c ] )

open_file.close()

"----------------------------------------------------------------------------------------------------------------"


# Recursive search of surface vertices

resu = [] # List of face polygones
allvisitedVertices = [] # Global list of visited vertices
NN_threshold = 4.0 # Max distance between points to be considered neighbours



def NN( vertex, lS ): #renvoie tous les plus proche voisin d'un vertex (qui s'exclue lui-meme de cette recherche)

    global NN_threshold

    allnearestNeighbours = [] #list of nearest neighbours
    allNNsegments = []

    for segment in lS:

        vertex0 = segment[0]
        vertex1 = segment[1]

        dist0 = sqrt( (vertex0[0] - vertex[0])**2 + (vertex0[1] - vertex[1])**2 + (vertex0[2] - vertex[2])**2 )
        dist1 = sqrt( (vertex1[0] - vertex[0])**2 + (vertex1[1] - vertex[1])**2 + (vertex1[2] - vertex[2])**2 )

        if( (dist0 < NN_threshold) and (vertex != vertex0) ):
            allnearestNeighbours.append( vertex0 )
            allNNsegments.append( segment )

        elif( (dist1 < NN_threshold) and (vertex != vertex1) ): # "elif": Ne peuvent normalement pas arriver simultanement si NN_threshold est bien choisi de toute facon...
            allnearestNeighbours.append( vertex1 )
            allNNsegments.append( [vertex1, vertex0] )

    return allnearestNeighbours, allNNsegments # NNsegments[i][0] needs to be nearestNeighbours[i]


def cullNN( allnearestNeighbours, allNNsegments, visitedVertices ):

    nearestNeighbours = [] #list of new nearest neighbours
    NNsegments = []

    # sort out the NNs that were already visited
    for i in range( len(allnearestNeighbours) ):

        if( allnearestNeighbours[i] in visitedVertices ):
            continue

        else:
            nearestNeighbours.append( allnearestNeighbours[i] )
            NNsegments.append( allNNsegments[i] )

    return nearestNeighbours, NNsegments


def add( nearestNeighbours0, nearestNeighbours1, NNsegments0, NNsegments1 ):

    nearestNeighbours = []
    NNsegments = []

    for i in range( len(nearestNeighbours0) ):

        if( nearestNeighbours0[i] in nearestNeighbours1 ):
            continue

        else:
            nearestNeighbours.append( nearestNeighbours0[i] )
            NNsegments.append( NNsegments0[i] )

    nearestNeighbours += nearestNeighbours1
    NNsegments += NNsegments1

    return nearestNeighbours, NNsegments

def addPoint(point, polygone):

    if( not(point in polygone) ):
        polygone.append( point )

def newFaceTest( segmentA, segmentB, neighbour ):

    #print "segA: ", segmentA, " segB: ", segmentB, " neighb: ", neighbour    

    A, B, neigh = np.array( segmentA[1] ) - np.array( segmentA[0] ), np.array( segmentB[1] ) - np.array( segmentB[0] ), np.array( neighbour[1] ) - np.array( neighbour[0] )

    crossAB = np.cross( A, B )

    norms = sqrt( crossAB.dot(crossAB) ) * sqrt( neigh.dot(neigh) )

    if norms ==0:
        print "\n \n ERROR !! \n \n"
        return False
    else:
        theta = np.arccos( sum([x * y for x, y in zip(crossAB, neigh)]) / norms )

    if (theta > pi/2):
        theta = pi - theta

    if ( theta < 1.2 ): # 70 degrees
        #print "\n \n", theta, "\n \n"
        return True

    #print "\n \n", theta, "\n \n"
    return False

def addNewPoly( poly ):

    global resu

    for polygone in resu:

            if ( len(polygone) == len(poly) ):

                polygoneIsPoly = True; # assumption to be tested

                for point in polygone: #works under the (correct) assumption that a polygone cannot have the same point twice

                    if not( point in poly ):
                        polygoneIsPoly = False
                        break

                if polygoneIsPoly: # if this is still true at this point, we know poly isnt a new face
                    return # we add nothing to resu and get out

    resu.append(poly)
    print "ADDED ", poly

                


def recursVertexSearch( lS, segment, visitedVertices, polygone, iteration ):

    global resu
    global allvisitedVertices

    stop = False

    vertex0 = segment[0]
    vertex1 = segment[1]

    allnearestNeighbours0, allNNsegments0 = NN( vertex0, lS ) # New nearest neighbours of vertex0 and the segments associated
    allnearestNeighbours1, allNNsegments1 = NN( vertex1, lS ) # New nearest neighbours of vertex1 and the segments associated

    nearestNeighbours0, NNsegments0 = cullNN( allnearestNeighbours0, allNNsegments0, visitedVertices + [vertex0] )
    nearestNeighbours1, NNsegments1 = cullNN( allnearestNeighbours1, allNNsegments1, visitedVertices + [vertex1] )

    nearestNeighbours, NNsegments = add( nearestNeighbours0, nearestNeighbours1, NNsegments0, NNsegments1) # Add without doubles

 # If a point has no neighbour at all, we considere it a polygone point
 # If it has neighbours but no new neighbour, we considere the middle point with its all-neighbours as a polygone point
 # If it has at least some new neighbours, we still have to considere the middle point with all neighbours including old ones...
       
    newpolygone0, newpolygone1 = [], []

    middle0 = vertex0
    for neighbour in allnearestNeighbours0:
        middle0 = map( sum, zip(middle0, neighbour) )
    middle0 = [ 1.0/(len(allnearestNeighbours0) + 1) * elmt for elmt in middle0]

    if( not(middle0 in polygone) ):
        newpolygone0.append(middle0)

#----
    middle1 = vertex1
    for neighbour in allnearestNeighbours1:
        middle1 = map( sum, zip(middle1, neighbour) )
    middle1 = [ 1.0/(len(allnearestNeighbours1) + 1) * elmt for elmt in middle1]
    
    if( not(middle1 in polygone) ):
        newpolygone1.append( middle1 )

    else:
        stop = True


 # Cas d'arret: si nearestNeighbours est vide (plus de nouveau voisins) on peut output le polygone.
 # Le polygone a ete gere par les lignes ci dessus...

    if( stop ): # QUELLE EST LA CONDITION D ARRET
        allvisitedVertices += visitedVertices # gives a lot of doubles: not problematic but loses time later...
        addNewPoly( polygone ) # prevent doubles
        #resu.append( polygone )

 # Regular case:

    else:

        isNewFace = False

        extendedPolygone = polygone + newpolygone1 + newpolygone0

        if polygone != []:

            for neighbour in NNsegments: # Pour chaque nouveau neighbour, on se pose la question: 
            # Est-on sur une nouvelle face?

                isNewFace = newFaceTest( segment, [ vertex1, polygone[0] ], neighbour )

                if isNewFace:

                    vV = list(visitedVertices)
                    try:
                        vV.remove( vertex1 )
                    except:
                        pass
                        

                    for neigh in NNsegments:
                        try:
                             vV.remove( neigh[0] )
                        except:
                            pass

                        try:
                             vV.remove( neigh[1] )
                        except:
                             pass

                    recursVertexSearch( lS, neighbour, vV, [], iteration + "NF-" )

                    try:
                        NNsegments1.remove( neighbour )
                    except:
                        NNsegments0.remove( neighbour )
               
        # Update visitedVertices with all new neighbour
        newvisitedVertices0, newvisitedVertices1 = [vertex0], [vertex1]

        for newSegment in NNsegments0:
            newvisitedVertices0 += newSegment

        for newSegment in NNsegments1:
            newvisitedVertices1 += newSegment

        # Affichage
        #print iteration, segment, '\n \n', "nearestNeighbours: ", nearestNeighbours, '\n', "NNsegments: ", NNsegments, '\n', "polygone: ", polygone, '\n', "visitedVertices0: ", visitedVertices + newvisitedVertices0, '\n', "visitedVertices1: ", visitedVertices + newvisitedVertices1, '\n', "allnearestNeighbours1: ",allnearestNeighbours1, '\n','\n','\n'

        # Do recursive calls
        i=0
        for newSegment in NNsegments0: 
            i+=1
            recursVertexSearch( lS, newSegment,  list(visitedVertices + newvisitedVertices0), list(polygone + newpolygone0), iteration + str(i) + "-" )

        for newSegment in NNsegments1:
            i+=1
            recursVertexSearch( lS, newSegment,  list(visitedVertices + newvisitedVertices1), list(polygone + newpolygone1), iteration + str(i) + "-" )


"----------------------------------------------------------------------------------------------------------------"

# Call it

allvisitedVertices = listSegments[0]
#print listSegments[0], '\n'
recursVertexSearch( listSegments, listSegments[0], [], [], "1-" )

#print "\n \n \n \n", newFaceTest( [[0.0, 0.0, 0.0],[0.0, 0.0, 1.0]], [[0.2, 0.0, 0.0],[0.0, 1.0, 0.0]], [[0.0, 0.0, 0.0],[0.0, 1.0, 1.0]] )

"""
k=0
while( (len(listSegments) != 0) or k > 5): # Proceed by connected components

    k += 1
    recursVertexSearch( listSegments, listSegments[0], listSegments[0], [] )
    
    for segment in listSegments:

        if( (segment[0] in allvisitedVertices) and (segment[1] in allvisitedVertices) ):
            
            listSegments.remove( segment )
            listSegments.remove( [segment[1], segment[0]] )

"""

def compact( list_poly ):

    class Found(Exception): pass

    alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
    alphabet_flag = 0

    named_points = []
    compact_resu = []

    for poly in list_poly:
        
        compact_resu.append([])

        for point in poly:

            try:
                for i in range( len(named_points) ): # ignored if named_points is empty
                    
                    if (named_points[i] == point): # this point already has a name, which is of course alphabet[i]

                        compact_resu[-1].append( alphabet[i] )
                        raise Found

            except Found: # if the point has found its name we can go to the next one 
                continue

            # else: give it a name
            compact_resu[-1].append( alphabet[alphabet_flag] )
            alphabet_flag += 1
            named_points.append( point )

    return compact_resu
                    

        

print resu
print( compact( resu ) )
print( len(resu) ), "\n"

"""plt.show()"""

"----------------------------------------------------------------------------------------------------------------"

# Do CoM triangulation for each polygone:

from scipy.spatial import Delaunay
import plotly.plotly as py
from plotly.tools import FigureFactory as FF
import plotly.graph_objs as go

"""
#Tracer les points en 3d:
resu_reshape = []
for polyg in resu:

    resu_reshape += polyg

points = np.array(resu_reshape) # np.array(polyg)

for p in points:

    ax.scatter3D( p[0], p[1], p[2], '+' )
"""
#--------------------------------------------------------------------------------------------------------

# Fit a plane passing as close as possible to the polygone points

"""
def localPlaneTransform2( polyg ):

    xs,ys,zs = zip(*polyg)
    print polyg, "\n \n"

    # plot raw data
    plt.figure()
    ax_l = plt.subplot(111, projection='3d')
    print "xs,ys,zs \n", xs,"\n \n", ys,"\n \n",zs
    ax_l.scatter(xs, ys, zs, color='b')

    # do fit
    tmp_A = []
    tmp_b = []
    for i in range(len(xs)):
        tmp_A.append([xs[i], ys[i], 1])
        tmp_b.append(zs[i])
    b = np.matrix(tmp_b).T
    A = np.matrix(tmp_A)
    fit = (A.T * A).I * A.T * b
    errors = b - A * fit
    residual = np.linalg.norm(errors)

    print "solution:"
    print "%f x + %f y + %f = z" % (fit[0], fit[1], fit[2])
    print "errors:"
    print errors
    print "residual:"
    print residual

    fitnp = np.array(fit)
    # plot plane
    xlim = ax_l.get_xlim()
    ylim = ax_l.get_ylim()
    X,Y = np.meshgrid(range(10), range(10))
    #X,Y = np.meshgrid(np.arange(xlim[0], xlim[1]),
                      #np.arange(ylim[0], ylim[1]))

    Z = (-fitnp[0] * X - fitnp[1] * Y - fitnp[2])

    # plot the surface
    #plt3d = plt.figure().gca(projection='3d')
    ax_l.plot_surface(X, Y, Z, alpha=0.2)

    plt.show()
"""


import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import scipy.optimize
import functools
"""

SHITTY because the 3 params plane parameters doesn't work with y = 0 planes!

def plane(x, y, params):
    a = params[0]
    b = params[1]
    c = params[2]
    z = a*x + b*y + c
    return z

def error(params, points):
    result = 0
    for (x,y,z) in points:
        plane_z = plane(x, y, params)
        diff = abs(plane_z - z)
        result += diff**2
    return result

def cross(a, b):
    return [a[1]*b[2] - a[2]*b[1],
            a[2]*b[0] - a[0]*b[2],
            a[0]*b[1] - a[1]*b[0]]


def localPlaneTransform( polyg ): # display a fitted plane on a set of 3D points
    fun = functools.partial(error, points=polyg)
    params0 = [0, 0, 0]
    res = scipy.optimize.minimize(fun, params0)

    a = res.x[0]
    b = res.x[1]
    c = res.x[2]

    print a, b, c

    gamma = sqrt(1 - a*a - b*b)
    
    if (gamma != 1):

        triedre = [ [-b/(1 - gamma*gamma), a/(1 - gamma*gamma), 0], [], [-a, -b, gamma] ]
        triedre[1] = cross( triedre[0], triedre[2] )

    else:
        triedre = [ [1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0] ]

    xs, ys, zs = zip(*polyg)

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    ax.scatter(xs, ys, zs)

    point  = np.array([0.0, 0.0, c])
    normal = np.array(cross([1,0,a], [0,1,b]))
    d = -point.dot(normal)
    xx, yy = np.meshgrid([min(xs),max(xs)], [min(ys),max(ys)])
    z = (-normal[0] * xx - normal[1] * yy - d) * 1. /normal[2]
    ax.plot_surface(xx, yy, z, alpha=0.2, color=[0,1,0])

    ax.set_xlim(min(xs) - 2, max(xs) + 2)
    ax.set_ylim(min(ys) - 2, max(ys) + 2)
    ax.set_zlim(min(zs) - 2, max(zs) + 2)

    plt.show()

    return triedre # triedre is the transpose of the transform matrix into the new frame...
"""





from numpy.linalg import svd

def cross(a, b):
    return [a[1]*b[2] - a[2]*b[1],
            a[2]*b[0] - a[0]*b[2],
            a[0]*b[1] - a[1]*b[0]]

def localPlaneTransform(X): # Optimal SVD-based plane-fitting to a 3D pointcloud
    """
    Singular value decomposition method.
    Source: https://gist.github.com/lambdalisue/7201028
    """
    # Find the average of points (centroid) along the columns
    C = np.average(X, axis=0)

    # Create CX vector (centroid to point) matrix
    CX = X - C
    # Singular value decomposition
    U, S, V = np.linalg.svd(CX)
    # The last row of V matrix indicate the eigenvectors of
    # smallest eigenvalues (singular values).
    N = V[-1]

    # Extract a, b, c, d coefficients.
    x0, y0, z0 = C
    a, b, c = N
    d = -(a * x0 + b * y0 + c * z0)

    if (c*c != 1.0):
        triedre = [[b/ sqrt(a*a + b*b), -a/sqrt(a*a + b*b), 0], [], [a, b, c]]
        triedre[1] = cross( triedre[2], triedre[0] ) # bon sens?
    else:
        triedre = [ [1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0] ]

    print "\n Triedre:", triedre
    return triedre

        
def projectPolygone( polyg, transform ): # transform must be a numpy array

    newPolyg = []

    for vertex in polyg:
        newPolyg.append( transform.dot(vertex) )

    return newPolyg


#=========== Test ==============
"""
for polyg in resu:

    newFrame = localPlaneTransform( polyg )
    transform = np.transpose(newFrame)
    print newFrame
"""
#===============================

def CenterOfMasses( polyg ): # CoM in 3D

    CoM = [0.0, 0.0, 0.0]

    i = len( polyg )

    for vertex in polyg:

        CoM[0] += vertex[0]/i
        CoM[1] += vertex[1]/i
        CoM[2] += vertex[2]/i
    
    return CoM
    

def less(pointA, pointB, center): # pointA and pointB are 3D points

    a, b = pointA[0:2], pointB[0:2] # a and b are 2D points

    #center = [ 0.5*(a[0] + b[0]), 0.5*(a[1] + b[1]) ]

    if (a[0] - center[0] >= 0 and b[0] - center[0] < 0):
        return True
    if (a[0] - center[0] < 0 and b[0] - center[0] >= 0):
        return False
    if (a[0] - center[0] == 0 and b[0] - center[0] == 0):
        if (a[1] - center[1] >= 0 or b[1] - center[1] >= 0):
            return a[1] > b[1]
        return b[1] > a[1]
    

    # compute the cross product of vectors (center -> a) x (center -> b)
    det = (a[0] - center[0]) * (b[1] - center[1]) - (b[0] - center[0]) * (a[1] - center[1]);
    if (det < 0):
        return True
    if (det > 0):
        return False

    # points a and b are on the same line from the center
    # check which point is closer to the center
    d1 = (a[0] - center[0]) * (a[0] - center[0]) + (a[1] - center[1]) * (a[1] - center[1])
    d2 = (b[0] - center[0]) * (b[0] - center[0]) + (b[1] - center[1]) * (b[1] - center[1])
    return d1 > d2

def quicksort2D(t, center): # quicksort for a list t of 3D points in 2D space (according to their x and y coordinates)

    if t == []:
        return []
    else:
        pivot = t[0]
        t1 = []
        t2 = []
        for x in t[1:]:
            if less(x, pivot, center):
                t1.append(x)
            else:
                t2.append(x)
        return quicksort2D(t1,center) + [pivot] + quicksort2D(t2,center)

#=========== Test ==============

polygaune = [ [0.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]

newFrame = localPlaneTransform( polygaune )
transform = np.transpose(newFrame)

#print np.array(transform).dot(newFrame)
polyg = projectPolygone( polygaune, transform )

print "\n Polygaune: ", polygaune, "\n Polyg: ", polyg

#"\n \n", quicksort2D( polygaune, CenterOfMasses(polygaune)[0:2] )

#===============================



def CoMTriangulation( polyg ):

    triangulation = []

    newFrame = localPlaneTransform( polyg )
    transform = np.transpose(newFrame)
    polyg = projectPolygone( polyg, transform ) # project polygone in plane's localframe

    center2D = CenterOfMasses( polyg )[0:2]
    print "\n center2D: ", projectPolygone( [center2D+[0.0]], np.linalg.inv(transform) ), "\n \n"
    polyg = quicksort2D( polyg, center2D ) # sort points

    polyg = projectPolygone( polyg, np.linalg.inv(transform) ) # reproject polygone back in global frame
    center3D = CenterOfMasses( polyg )

    for i in range(len(polyg) - 1):

        triangulation.append( [ polyg[i], center3D, polyg[i+1] ] )

    triangulation.append( [ polyg[-1], center3D, polyg[0] ] )

    return triangulation


colors = ["red", "blue", "green", "yellow"]

def displayTriangles( listTriangles ):

    figtri = plt.figure()
    ax = figtri.add_subplot(111, projection='3d')

    i = 0
    for triangle in listTriangles:
        
        i += 1
        i = i%4

        point1 = triangle[0]
        print point1
        ax.scatter(point1[0], point1[1], point1[2], c = colors[i])

        point2 = triangle[1]
        print point2
        ax.scatter(point2[0], point2[1], point2[2], c = colors[i])

        point3 = triangle[2]
        print point3
        ax.scatter(point3[0], point3[1], point3[2], c = colors[i])

    plt.show()

#print CoMTriangulation(resu[0])

save_file = open(save_file_path, "w")

for polyg in resu:

    resu_triangles = CoMTriangulation(polyg)
    displayTriangles( resu_triangles )

    for triangle in resu_triangles:

        save_file.write(str(triangle[0][0]) + " " + str(triangle[0][1]) + " " + str(triangle[0][2]) + "\n")
        save_file.write(str(triangle[1][0]) + " " + str(triangle[1][1]) + " " + str(triangle[1][2]) + "\n")
        save_file.write(str(triangle[2][0]) + " " + str(triangle[2][1]) + " " + str(triangle[2][2]) + "\n")

save_file.close()

#--------------------------------------------------------------------------------------------------------

#Just some displaying test function:

"""
for polyg in resu:

    fig = plt.figure()
    ax = fig.gca(projection='3d')

    X,Y,Z = zip(*polyg)
    ax.scatter3D( X, Y, Z, '+' )
    plt.show()
"""
